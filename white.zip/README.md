 <h1 align="center">Boronide Obfuscator!</i></a></h1>
 
## Feautures
* Instruction Shuffle
* Constant Shuffle
* Fake Constants
* Fake Code
* Anti Tamper
* Meme strings

# Usage

Usage:
go to ```../temp/input.lua``` and put your script

and put the following command in your terminal
```node run.js```

# Credits
Discord Server: https://discord.gg/5ktJ7TedTf

